﻿// Nightvision NightVision StringExtensions.cs
// 
// 06 12 2018
// 
// 06 12 2018

namespace NightVision
{
    public static class StringExtensions
    { }
}